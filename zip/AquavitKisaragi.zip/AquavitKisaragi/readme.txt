﻿プロジェクトのタイトル
	AquavitKisaragi

プロジェクトの概要説明
	OCRで画面を読み込みファイルに吐き出します。
	Softalkなどのソフトと連携すれば音声を出力することもできます。

必要条件
	windows10以上（だと思うよ！）

使用言語、環境、テクノロジー
	C#

使い方
	なんとなくでお願いします。
	ScanSettingボタン
		OCRの位置指定
	recordingボタン
		OCRの開始し、レコーディングデータのテキストファイルを出力します。
		同時に再生することも可能です。
	FileSaveボタン
		レコーディングデータのテキストファイルを保存する
	FileOpenボタン
		レコーディングデータのテキストファイルを開く
	FileTalkボタン
		レコーディングデータのテキストファイルを再生

インストール方法
	解凍したフォルダ直下にSoftalkのフォルダを置きましょう
	
	例：AquavitKisaragi\softalk\SofTalk.exe

ライセンス情報
	アクアビット・キサラギ
	Twitter（@TMarunoko）

	オススメな音声再生ソフト
	https://w.atwiki.jp/softalk/

	MouseHook.csを利用させていただいています。
	https://gist.github.com/tarukosu/e8b869cf700ac1c91901fc065731a3a3

今後の計画
	予定は未定